DROP DATABASE IF EXISTS muse_db;
CREATE DATABASE muse_db CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE muse_db;

CREATE TABLE `languages` (
  `language_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `iso_code` varchar(3) NOT NULL,
  `name` varchar(40) NOT NULL,
  `native_name` varchar(40) NOT NULL,
  `script` varchar(30) NOT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `uq_languages_iso` (`iso_code`),
  UNIQUE KEY `uq_languages_name` (`name`),
  CONSTRAINT `chk_languages_iso` CHECK (regexp_like(`iso_code`,'^[a-z]{2,3}$','c'))
) ENGINE=InnoDB;

CREATE TABLE `films` (
  `film_id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `release_year` smallint unsigned NOT NULL,
  `language_id` smallint unsigned NOT NULL,
  PRIMARY KEY (`film_id`),
  UNIQUE KEY `uq_films_identity` (`title`,`release_year`,`language_id`),
  KEY `fk_films_lang` (`language_id`),
  CONSTRAINT `fk_films_lang` FOREIGN KEY (`language_id`) REFERENCES `languages` (`language_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_films_year` CHECK ((`release_year` between 1900 and 2100))
) ENGINE=InnoDB;

CREATE TABLE `albums` (
  `album_id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `normalized_title` varchar(150) GENERATED ALWAYS AS (trim(regexp_replace(lower(`title`),'[!-/:-@\\[-`{-~—–‘’“”[:space:]]+',' '))) STORED,
  `album_type` enum('ALBUM','EP','SINGLE','SOUNDTRACK','COMPILATION') NOT NULL DEFAULT 'ALBUM',
  `film_id` int unsigned DEFAULT NULL,
  `release_year` smallint unsigned NOT NULL,
  `language_id` smallint unsigned DEFAULT NULL,
  `cover_color_1` char(7) NOT NULL,
  `cover_color_2` char(7) NOT NULL,
  PRIMARY KEY (`album_id`),
  KEY `idx_albums_normalized` (`normalized_title`),
  KEY `fk_albums_film` (`film_id`),
  KEY `fk_albums_lang` (`language_id`),
  FULLTEXT KEY `ft_albums_title` (`title`) WITH PARSER ngram,
  CONSTRAINT `fk_albums_film` FOREIGN KEY (`film_id`) REFERENCES `films` (`film_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_albums_lang` FOREIGN KEY (`language_id`) REFERENCES `languages` (`language_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_albums_colors` CHECK ((regexp_like(`cover_color_1`,'^#[0-9A-Fa-f]{6}$') and regexp_like(`cover_color_2`,'^#[0-9A-Fa-f]{6}$'))),
  CONSTRAINT `chk_albums_film` CHECK (((`film_id` is null) or (`album_type` = 'SOUNDTRACK'))),
  CONSTRAINT `chk_albums_year` CHECK ((`release_year` between 1900 and 2100))
) ENGINE=InnoDB;

CREATE TABLE `regions` (
  `region_code` varchar(6) NOT NULL,
  `name` varchar(60) NOT NULL,
  `country_code` char(2) NOT NULL,
  `primary_language_id` smallint unsigned DEFAULT NULL,
  PRIMARY KEY (`region_code`),
  UNIQUE KEY `uq_regions_name` (`name`),
  KEY `fk_regions_language` (`primary_language_id`),
  CONSTRAINT `fk_regions_language` FOREIGN KEY (`primary_language_id`) REFERENCES `languages` (`language_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_regions_code` CHECK (regexp_like(`region_code`,'^[A-Z]{2}(-[A-Z]{2,3})?$','c'))
) ENGINE=InnoDB;

CREATE TABLE `artists` (
  `artist_id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `normalized_name` varchar(100) GENERATED ALWAYS AS (trim(regexp_replace(lower(`name`),'[!-/:-@\\[-`{-~—–‘’“”[:space:]]+',' '))) STORED,
  `disambiguation` varchar(80) NOT NULL DEFAULT '',
  `artist_type` enum('SOLO','GROUP','COMPOSER','ORCHESTRA') NOT NULL DEFAULT 'SOLO',
  `country_code` char(2) NOT NULL DEFAULT 'IN',
  `region_code` varchar(6) DEFAULT NULL,
  `primary_language_id` smallint unsigned DEFAULT NULL,
  `formed_year` smallint unsigned DEFAULT NULL,
  `bio` varchar(400) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`artist_id`),
  UNIQUE KEY `uq_artists_identity` (`normalized_name`,`disambiguation`),
  KEY `fk_artists_region` (`region_code`),
  KEY `fk_artists_lang` (`primary_language_id`),
  FULLTEXT KEY `ft_artists_name` (`name`) WITH PARSER ngram,
  CONSTRAINT `fk_artists_lang` FOREIGN KEY (`primary_language_id`) REFERENCES `languages` (`language_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_artists_region` FOREIGN KEY (`region_code`) REFERENCES `regions` (`region_code`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_artists_year` CHECK (((`formed_year` is null) or (`formed_year` between 1900 and 2100)))
) ENGINE=InnoDB;

CREATE TABLE `album_artists` (
  `album_id` int unsigned NOT NULL,
  `artist_id` int unsigned NOT NULL,
  `credit_order` tinyint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`album_id`,`artist_id`),
  KEY `idx_aa_artist` (`artist_id`),
  CONSTRAINT `fk_aa_album` FOREIGN KEY (`album_id`) REFERENCES `albums` (`album_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_aa_artist` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`artist_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `world_archetypes` (
  `archetype_code` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `description` varchar(200) NOT NULL,
  `motif` enum('ORBITS','WAVES','PEAKS','RAIN','SUNBURST','GRID','STARS','EMBERS') NOT NULL,
  `palette` json NOT NULL,
  `title_words` json NOT NULL,
  `season_months` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`archetype_code`),
  UNIQUE KEY `uq_archetype_name` (`name`),
  CONSTRAINT `chk_arch_palette` CHECK ((json_length(`palette`) between 3 and 6))
) ENGINE=InnoDB;

CREATE TABLE `mood_categories` (
  `category_id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `quadrant` enum('BRIGHT_HIGH','BRIGHT_LOW','DARK_HIGH','DARK_LOW') NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `uq_mc_name` (`name`),
  UNIQUE KEY `uq_mc_quadrant` (`quadrant`)
) ENGINE=InnoDB;

CREATE TABLE `moods` (
  `mood_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` tinyint unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `emoji` varchar(8) NOT NULL,
  `color_hex` char(7) NOT NULL,
  `description` varchar(200) NOT NULL,
  `target_energy` decimal(4,3) NOT NULL,
  `target_valence` decimal(4,3) NOT NULL,
  `target_danceability` decimal(4,3) NOT NULL,
  `target_acousticness` decimal(4,3) NOT NULL,
  `target_instrumentalness` decimal(4,3) NOT NULL,
  `tempo_min` decimal(5,1) NOT NULL,
  `tempo_max` decimal(5,1) NOT NULL,
  PRIMARY KEY (`mood_id`),
  UNIQUE KEY `uq_moods_name` (`name`),
  KEY `fk_moods_category` (`category_id`),
  CONSTRAINT `fk_moods_category` FOREIGN KEY (`category_id`) REFERENCES `mood_categories` (`category_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_moods_color` CHECK (regexp_like(`color_hex`,'^#[0-9A-Fa-f]{6}$')),
  CONSTRAINT `chk_moods_targets` CHECK (((`target_energy` between 0 and 1) and (`target_valence` between 0 and 1) and (`target_danceability` between 0 and 1) and (`target_acousticness` between 0 and 1) and (`target_instrumentalness` between 0 and 1))),
  CONSTRAINT `chk_moods_tempo` CHECK (((`tempo_min` >= 40) and (`tempo_max` <= 220) and (`tempo_min` < `tempo_max`)))
) ENGINE=InnoDB;

CREATE TABLE `archetype_moods` (
  `archetype_code` varchar(20) NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `weight` decimal(3,2) NOT NULL,
  PRIMARY KEY (`archetype_code`,`mood_id`),
  KEY `fk_am_mood` (`mood_id`),
  CONSTRAINT `fk_am_arch` FOREIGN KEY (`archetype_code`) REFERENCES `world_archetypes` (`archetype_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_am_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_am_weight` CHECK (((`weight` > 0) and (`weight` <= 1)))
) ENGINE=InnoDB;

CREATE TABLE `artist_aliases` (
  `alias_id` int unsigned NOT NULL AUTO_INCREMENT,
  `artist_id` int unsigned NOT NULL,
  `alias` varchar(100) NOT NULL,
  `normalized_alias` varchar(100) GENERATED ALWAYS AS (trim(regexp_replace(lower(`alias`),'[!-/:-@\\[-`{-~—–‘’“”[:space:]]+',' '))) STORED,
  `alias_type` enum('SPELLING','TRANSLITERATION','NATIVE_SCRIPT','STAGE_NAME') NOT NULL,
  PRIMARY KEY (`alias_id`),
  UNIQUE KEY `uq_aliases_artist_alias` (`artist_id`,`normalized_alias`),
  KEY `idx_aliases_normalized` (`normalized_alias`),
  FULLTEXT KEY `ft_aliases_alias` (`alias`) WITH PARSER ngram,
  CONSTRAINT `fk_aliases_artist` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`artist_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `intelligence_models` (
  `model_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `kind` enum('AUDIO_FEATURES','MOOD','SEGMENTS','PREFERENCE','RECOMMENDER','WORLD') NOT NULL,
  `name` varchar(40) NOT NULL,
  `version` varchar(20) NOT NULL,
  `description` varchar(300) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `active_kind` varchar(20) GENERATED ALWAYS AS (if((`is_active` = 1),`kind`,NULL)) VIRTUAL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`model_id`),
  UNIQUE KEY `uq_models_version` (`kind`,`name`,`version`),
  UNIQUE KEY `uq_models_one_active` (`active_kind`)
) ENGINE=InnoDB;

CREATE TABLE `songs` (
  `song_id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `normalized_title` varchar(150) GENERATED ALWAYS AS (trim(regexp_replace(lower(`title`),'[!-/:-@\\[-`{-~—–‘’“”[:space:]]+',' '))) STORED,
  `version_label` varchar(40) NOT NULL DEFAULT '',
  `primary_artist_id` int unsigned NOT NULL,
  `album_id` int unsigned DEFAULT NULL,
  `track_number` tinyint unsigned DEFAULT NULL,
  `duration_sec` smallint unsigned NOT NULL,
  `release_year` smallint unsigned NOT NULL,
  `language_id` smallint unsigned DEFAULT NULL,
  `isrc` char(12) DEFAULT NULL,
  `explicit` tinyint(1) NOT NULL DEFAULT '0',
  `content_rating` enum('ALL','TEEN','MATURE') NOT NULL DEFAULT 'ALL',
  `popularity` tinyint unsigned NOT NULL DEFAULT '50',
  `status` enum('ACTIVE','PENDING_ANALYSIS','HIDDEN','MERGED') NOT NULL DEFAULT 'ACTIVE',
  `merged_into_song_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`song_id`),
  UNIQUE KEY `uq_songs_identity` (`primary_artist_id`,`normalized_title`,`version_label`),
  UNIQUE KEY `uq_songs_isrc` (`isrc`),
  KEY `idx_songs_album` (`album_id`,`track_number`),
  KEY `idx_songs_lang_status` (`language_id`,`status`),
  KEY `idx_songs_status_pop` (`status`,`popularity`),
  KEY `fk_songs_merged` (`merged_into_song_id`),
  FULLTEXT KEY `ft_songs_title` (`title`) WITH PARSER ngram,
  CONSTRAINT `fk_songs_album` FOREIGN KEY (`album_id`) REFERENCES `albums` (`album_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_songs_artist` FOREIGN KEY (`primary_artist_id`) REFERENCES `artists` (`artist_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_songs_lang` FOREIGN KEY (`language_id`) REFERENCES `languages` (`language_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_songs_merged` FOREIGN KEY (`merged_into_song_id`) REFERENCES `songs` (`song_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_songs_duration` CHECK ((`duration_sec` between 30 and 1800)),
  CONSTRAINT `chk_songs_explicit` CHECK (((`explicit` = 0) or (`content_rating` <> 'ALL'))),
  CONSTRAINT `chk_songs_isrc` CHECK (((`isrc` is null) or regexp_like(`isrc`,'^[A-Z]{2}[A-Z0-9]{3}[0-9]{7}$','c'))),
  CONSTRAINT `chk_songs_merge` CHECK (((`status` = 'MERGED') = (`merged_into_song_id` is not null))),
  CONSTRAINT `chk_songs_pop` CHECK ((`popularity` <= 100)),
  CONSTRAINT `chk_songs_year` CHECK ((`release_year` between 1900 and 2100))
) ENGINE=InnoDB;

CREATE TABLE `audio_features` (
  `feature_id` int unsigned NOT NULL AUTO_INCREMENT,
  `song_id` int unsigned NOT NULL,
  `model_id` smallint unsigned NOT NULL,
  `energy` decimal(4,3) NOT NULL,
  `valence` decimal(4,3) NOT NULL,
  `danceability` decimal(4,3) NOT NULL,
  `acousticness` decimal(4,3) NOT NULL,
  `instrumentalness` decimal(4,3) NOT NULL,
  `speechiness` decimal(4,3) NOT NULL,
  `loudness_db` decimal(5,2) NOT NULL,
  `tempo_bpm` decimal(5,1) NOT NULL,
  `musical_key` tinyint unsigned NOT NULL,
  `mode` tinyint unsigned NOT NULL,
  `analyzed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `current_song_key` int unsigned GENERATED ALWAYS AS (if((`is_current` = 1),`song_id`,NULL)) VIRTUAL,
  PRIMARY KEY (`feature_id`),
  UNIQUE KEY `uq_af_song_model` (`song_id`,`model_id`),
  UNIQUE KEY `uq_af_one_current` (`current_song_key`),
  KEY `idx_af_energy_valence` (`energy`,`valence`),
  KEY `fk_af_model` (`model_id`),
  CONSTRAINT `fk_af_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_af_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_af_key` CHECK (((`musical_key` <= 11) and (`mode` in (0,1)))),
  CONSTRAINT `chk_af_loudness` CHECK ((`loudness_db` between -(60) and 0)),
  CONSTRAINT `chk_af_tempo` CHECK ((`tempo_bpm` between 40 and 220)),
  CONSTRAINT `chk_af_unit` CHECK (((`energy` between 0 and 1) and (`valence` between 0 and 1) and (`danceability` between 0 and 1) and (`acousticness` between 0 and 1) and (`instrumentalness` between 0 and 1) and (`speechiness` between 0 and 1)))
) ENGINE=InnoDB;

CREATE TABLE `roles` (
  `role_id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uq_roles_code` (`code`)
) ENGINE=InnoDB;

CREATE TABLE `users` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password_hash` char(60) NOT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `role_id` tinyint unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `failed_login_count` tinyint unsigned NOT NULL DEFAULT '0',
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `fk_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `chk_users_email` CHECK ((`email` like '%_@_%._%')),
  CONSTRAINT `chk_users_username` CHECK (regexp_like(`username`,'^[a-z0-9_]{3,30}$','c'))
) ENGINE=InnoDB;

CREATE TABLE `audit_logs` (
  `audit_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_user_id` int unsigned DEFAULT NULL,
  `action` varchar(40) NOT NULL,
  `entity_type` varchar(30) NOT NULL,
  `entity_id` varchar(40) NOT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`audit_id`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  KEY `idx_audit_time` (`created_at`),
  KEY `idx_audit_actor` (`actor_user_id`,`created_at`),
  CONSTRAINT `fk_audit_actor` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `auth_sessions` (
  `session_id` char(16) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `user_id` int unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `revoke_reason` enum('LOGOUT','LOGOUT_ALL','PASSWORD_CHANGED','ADMIN_DEACTIVATED','REVOKED_BY_USER','ACCOUNT_DELETED') DEFAULT NULL,
  `user_agent` varchar(160) DEFAULT NULL,
  `ip_hash` char(64) DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `uq_session_token` (`token_hash`),
  KEY `idx_session_user` (`user_id`,`revoked_at`,`expires_at`),
  KEY `idx_session_expiry` (`expires_at`),
  CONSTRAINT `fk_session_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_session_revoke` CHECK (((`revoked_at` is null) = (`revoke_reason` is null))),
  CONSTRAINT `chk_session_times` CHECK (((`expires_at` > `created_at`) and (`last_seen_at` >= `created_at`)))
) ENGINE=InnoDB;

CREATE TABLE `contexts` (
  `context_id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `emoji` varchar(8) NOT NULL,
  `description` varchar(200) NOT NULL,
  `target_energy` decimal(4,3) NOT NULL,
  `target_valence` decimal(4,3) NOT NULL,
  `target_danceability` decimal(4,3) NOT NULL,
  `target_acousticness` decimal(4,3) NOT NULL,
  `target_instrumentalness` decimal(4,3) NOT NULL,
  `tempo_min` decimal(5,1) NOT NULL,
  `tempo_max` decimal(5,1) NOT NULL,
  `max_speechiness` decimal(4,3) NOT NULL DEFAULT '1.000',
  `sort_order` tinyint unsigned NOT NULL,
  PRIMARY KEY (`context_id`),
  UNIQUE KEY `uq_contexts_code` (`code`),
  CONSTRAINT `chk_ctx_code` CHECK (regexp_like(`code`,'^[A-Z_]{2,20}$','c')),
  CONSTRAINT `chk_ctx_targets` CHECK (((`target_energy` between 0 and 1) and (`target_valence` between 0 and 1) and (`target_danceability` between 0 and 1) and (`target_acousticness` between 0 and 1) and (`target_instrumentalness` between 0 and 1) and (`max_speechiness` between 0 and 1))),
  CONSTRAINT `chk_ctx_tempo` CHECK (((`tempo_min` >= 40) and (`tempo_max` <= 220) and (`tempo_min` < `tempo_max`)))
) ENGINE=InnoDB;

CREATE TABLE `context_keywords` (
  `phrase` varchar(60) NOT NULL,
  `context_id` tinyint unsigned NOT NULL,
  PRIMARY KEY (`phrase`),
  KEY `fk_ck_ctx` (`context_id`),
  CONSTRAINT `fk_ck_ctx` FOREIGN KEY (`context_id`) REFERENCES `contexts` (`context_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ck_lower` CHECK ((`phrase` = lower(`phrase`)))
) ENGINE=InnoDB;

CREATE TABLE `context_moods` (
  `context_id` tinyint unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `weight` decimal(3,2) NOT NULL,
  PRIMARY KEY (`context_id`,`mood_id`),
  KEY `fk_cm_mood` (`mood_id`),
  CONSTRAINT `fk_cm_ctx` FOREIGN KEY (`context_id`) REFERENCES `contexts` (`context_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cm_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_cm_weight` CHECK (((`weight` > 0) and (`weight` <= 1)))
) ENGINE=InnoDB;

CREATE TABLE `genres` (
  `genre_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `parent_genre_id` smallint unsigned DEFAULT NULL,
  `color_hex` char(7) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`genre_id`),
  UNIQUE KEY `uq_genres_name` (`name`),
  KEY `fk_genres_parent` (`parent_genre_id`),
  CONSTRAINT `fk_genres_parent` FOREIGN KEY (`parent_genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_genres_color` CHECK (regexp_like(`color_hex`,'^#[0-9A-Fa-f]{6}$'))
) ENGINE=InnoDB;

CREATE TABLE `incognito_sessions` (
  `incognito_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `current_mood_id` smallint unsigned DEFAULT NULL,
  `status` enum('ACTIVE','ENDED','EXPIRED') NOT NULL DEFAULT 'ACTIVE',
  `active_user_key` int unsigned GENERATED ALWAYS AS (if((`status` = 'ACTIVE'),`user_id`,NULL)) VIRTUAL,
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`incognito_id`),
  UNIQUE KEY `uq_incog_one_active` (`active_user_key`),
  KEY `idx_incog_expiry` (`status`,`expires_at`),
  KEY `fk_incog_user` (`user_id`),
  KEY `fk_incog_mood` (`current_mood_id`),
  CONSTRAINT `fk_incog_mood` FOREIGN KEY (`current_mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incog_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_incog_state` CHECK (((`status` = 'ACTIVE') = (`ended_at` is null))),
  CONSTRAINT `chk_incog_times` CHECK (((`expires_at` > `started_at`) and ((`ended_at` is null) or (`ended_at` >= `started_at`))))
) ENGINE=InnoDB;

CREATE TABLE `incognito_events` (
  `event_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `incognito_id` bigint unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `listened_sec` smallint unsigned NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `skipped` tinyint(1) NOT NULL DEFAULT '0',
  `occurred_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_id`),
  KEY `idx_ie_session` (`incognito_id`,`occurred_at`),
  KEY `fk_ie_song` (`song_id`),
  CONSTRAINT `fk_ie_session` FOREIGN KEY (`incognito_id`) REFERENCES `incognito_sessions` (`incognito_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ie_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ie_flags` CHECK (((`completed` <> 1) or (`skipped` <> 1)))
) ENGINE=InnoDB;

CREATE TABLE `recommendation_batches` (
  `batch_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `incognito_id` bigint unsigned DEFAULT NULL,
  `model_id` smallint unsigned NOT NULL,
  `strategy` enum('MOOD','TEXT','CONTEXT','DAILY','SIMILAR','TRENDING','DISCOVERY','REGIONAL','WORLD','SMART_PLAYLIST','RECOVERY') NOT NULL,
  `label` varchar(120) DEFAULT NULL,
  `input_text` varchar(280) DEFAULT NULL,
  `context_id` tinyint unsigned DEFAULT NULL,
  `seed_song_id` int unsigned DEFAULT NULL,
  `language_id` smallint unsigned DEFAULT NULL,
  `target_energy` decimal(4,3) NOT NULL,
  `target_valence` decimal(4,3) NOT NULL,
  `target_danceability` decimal(4,3) NOT NULL,
  `target_acousticness` decimal(4,3) NOT NULL,
  `target_instrumentalness` decimal(4,3) NOT NULL,
  `tempo_min` decimal(5,1) NOT NULL,
  `tempo_max` decimal(5,1) NOT NULL,
  `max_speechiness` decimal(4,3) NOT NULL DEFAULT '1.000',
  `discovery_only` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`batch_id`),
  KEY `idx_rb_user_time` (`user_id`,`created_at`),
  KEY `fk_rb_model` (`model_id`),
  KEY `fk_rb_ctx` (`context_id`),
  KEY `fk_rb_seed` (`seed_song_id`),
  KEY `fk_rb_lang` (`language_id`),
  KEY `fk_rb_incognito` (`incognito_id`),
  CONSTRAINT `fk_rb_ctx` FOREIGN KEY (`context_id`) REFERENCES `contexts` (`context_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rb_incognito` FOREIGN KEY (`incognito_id`) REFERENCES `incognito_sessions` (`incognito_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rb_lang` FOREIGN KEY (`language_id`) REFERENCES `languages` (`language_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rb_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_rb_seed` FOREIGN KEY (`seed_song_id`) REFERENCES `songs` (`song_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rb_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_rb_targets` CHECK (((`target_energy` between 0 and 1) and (`target_valence` between 0 and 1) and (`target_danceability` between 0 and 1) and (`target_acousticness` between 0 and 1) and (`target_instrumentalness` between 0 and 1) and (`max_speechiness` between 0 and 1))),
  CONSTRAINT `chk_rb_tempo` CHECK ((`tempo_min` < `tempo_max`))
) ENGINE=InnoDB;

CREATE TABLE `listening_sessions` (
  `session_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `context_id` tinyint unsigned DEFAULT NULL,
  `device` varchar(30) NOT NULL DEFAULT 'web',
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` datetime DEFAULT NULL,
  `status` enum('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN',
  `plays` smallint unsigned NOT NULL DEFAULT '0',
  `listen_sec` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `uq_ls_session_user` (`session_id`,`user_id`),
  KEY `idx_ls_user_status` (`user_id`,`status`,`last_activity_at`),
  KEY `fk_ls_ctx` (`context_id`),
  CONSTRAINT `fk_ls_ctx` FOREIGN KEY (`context_id`) REFERENCES `contexts` (`context_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ls_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ls_state` CHECK ((((`status` = 'OPEN') and (`ended_at` is null)) or ((`status` = 'CLOSED') and (`ended_at` is not null) and (`ended_at` >= `started_at`))))
) ENGINE=InnoDB;

CREATE TABLE `listening_history` (
  `play_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `batch_id` bigint unsigned DEFAULT NULL,
  `origin` enum('HOME','MOOD','CONTEXT','WORLD','SEARCH','PLAYLIST','LIBRARY','SMART_PLAYLIST') NOT NULL DEFAULT 'HOME',
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` datetime DEFAULT NULL,
  `listened_sec` smallint unsigned NOT NULL DEFAULT '0',
  `completion_pct` decimal(5,2) NOT NULL DEFAULT '0.00',
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `skipped` tinyint(1) NOT NULL DEFAULT '0',
  `is_replay` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`play_id`),
  KEY `idx_lh_user_time` (`user_id`,`started_at`),
  KEY `idx_lh_user_song` (`user_id`,`song_id`,`started_at`),
  KEY `idx_lh_song_time` (`song_id`,`started_at`),
  KEY `idx_lh_session` (`session_id`),
  KEY `fk_lh_session_user` (`session_id`,`user_id`),
  KEY `fk_lh_batch` (`batch_id`),
  CONSTRAINT `fk_lh_batch` FOREIGN KEY (`batch_id`) REFERENCES `recommendation_batches` (`batch_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lh_session_user` FOREIGN KEY (`session_id`, `user_id`) REFERENCES `listening_sessions` (`session_id`, `user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lh_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_lh_end` CHECK (((`ended_at` is null) or (`ended_at` >= `started_at`))),
  CONSTRAINT `chk_lh_flags` CHECK (((`completed` <> 1) or (`skipped` <> 1))),
  CONSTRAINT `chk_lh_pct` CHECK ((`completion_pct` between 0 and 100))
) ENGINE=InnoDB;

CREATE TABLE `model_parameters` (
  `model_id` smallint unsigned NOT NULL,
  `param_code` varchar(40) NOT NULL,
  `param_value` decimal(10,4) NOT NULL,
  `min_value` decimal(10,4) NOT NULL,
  `max_value` decimal(10,4) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`model_id`,`param_code`),
  CONSTRAINT `fk_mp_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_mp_range` CHECK (((`min_value` <= `max_value`) and (`param_value` between `min_value` and `max_value`)))
) ENGINE=InnoDB;

CREATE TABLE `mood_keywords` (
  `keyword_id` int unsigned NOT NULL AUTO_INCREMENT,
  `phrase` varchar(60) NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `weight` decimal(3,2) NOT NULL,
  PRIMARY KEY (`keyword_id`),
  UNIQUE KEY `uq_mk` (`phrase`,`mood_id`),
  KEY `idx_mk_mood` (`mood_id`),
  CONSTRAINT `fk_mk_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_mk_lower` CHECK ((`phrase` = lower(`phrase`))),
  CONSTRAINT `chk_mk_weight` CHECK (((`weight` > 0) and (`weight` <= 1)))
) ENGINE=InnoDB;

CREATE TABLE `mood_segments` (
  `segment_id` int unsigned NOT NULL AUTO_INCREMENT,
  `song_id` int unsigned NOT NULL,
  `model_id` smallint unsigned NOT NULL,
  `segment_index` tinyint unsigned NOT NULL,
  `start_sec` smallint unsigned NOT NULL,
  `end_sec` smallint unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `confidence` decimal(4,3) NOT NULL,
  `energy` decimal(4,3) NOT NULL,
  `valence` decimal(4,3) NOT NULL,
  `analyzed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`segment_id`),
  UNIQUE KEY `uq_ms_order` (`song_id`,`model_id`,`segment_index`),
  KEY `fk_ms_model` (`model_id`),
  KEY `fk_ms_mood` (`mood_id`),
  CONSTRAINT `fk_ms_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ms_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ms_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ms_span` CHECK ((`start_sec` < `end_sec`)),
  CONSTRAINT `chk_ms_vals` CHECK (((`confidence` > 0) and (`confidence` <= 1) and (`energy` between 0 and 1) and (`valence` between 0 and 1)))
) ENGINE=InnoDB;

CREATE TABLE `music_sources` (
  `source_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name` varchar(80) NOT NULL,
  `source_type` enum('MUSIC_METADATA','AUDIO_ANALYSIS','MUSIC_AUDIO','PLAYBACK','MOVIE_METADATA','ARTWORK','VIDEO_METADATA') NOT NULL,
  `access_method` enum('API','FILE_FEED','GENERATED','USER_UPLOAD','MANUAL') NOT NULL,
  `base_url` varchar(255) DEFAULT NULL,
  `license_name` varchar(120) NOT NULL,
  `rights_scope` set('METADATA','AUDIO_FEATURES','AUDIO_PREVIEW','AUDIO_FULL','ARTWORK') NOT NULL,
  `requires_attribution` tinyint(1) NOT NULL DEFAULT '0',
  `attribution_text` varchar(255) DEFAULT NULL,
  `priority` tinyint unsigned NOT NULL DEFAULT '50',
  `fallback_source_id` smallint unsigned DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `requires_credentials` tinyint(1) NOT NULL DEFAULT '0',
  `last_success_at` datetime DEFAULT NULL,
  `notes` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`source_id`),
  UNIQUE KEY `uq_sources_code` (`code`),
  KEY `fk_sources_fallback` (`fallback_source_id`),
  CONSTRAINT `fk_sources_fallback` FOREIGN KEY (`fallback_source_id`) REFERENCES `music_sources` (`source_id`) ON DELETE SET NULL,
  CONSTRAINT `chk_sources_attrib` CHECK (((`requires_attribution` = 0) or (`attribution_text` is not null)))
) ENGINE=InnoDB;

CREATE TABLE `permissions` (
  `permission_code` varchar(40) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`permission_code`)
) ENGINE=InnoDB;

CREATE TABLE `pipeline_jobs` (
  `job_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_type` enum('INGEST_SOURCE','AUDIO_ANALYSIS','MOOD_ANALYSIS','TREND_SNAPSHOT','WORLD_GENERATION','WEEKLY_INTELLIGENCE','PREFERENCE_REFRESH','INCOGNITO_CLEANUP','SESSION_CLOSE') NOT NULL,
  `parent_job_id` bigint unsigned DEFAULT NULL,
  `source_id` smallint unsigned DEFAULT NULL,
  `idempotency_key` varchar(120) NOT NULL,
  `status` enum('DISCOVERED','VALIDATING','PROCESSING','COMPLETED','SKIPPED','FAILED') NOT NULL DEFAULT 'DISCOVERED',
  `params` json DEFAULT NULL,
  `processing_version` varchar(20) NOT NULL,
  `retry_count` tinyint unsigned NOT NULL DEFAULT '0',
  `max_retries` tinyint unsigned NOT NULL DEFAULT '3',
  `next_attempt_at` datetime DEFAULT NULL,
  `locked_by` varchar(64) DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `requested_by` int unsigned DEFAULT NULL,
  `stats` json DEFAULT NULL,
  `last_error` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  UNIQUE KEY `uq_jobs_idem` (`idempotency_key`),
  KEY `idx_jobs_claim` (`status`,`next_attempt_at`),
  KEY `idx_jobs_queue` (`status`,`job_id`),
  KEY `idx_jobs_type_time` (`job_type`,`created_at`),
  KEY `fk_jobs_parent` (`parent_job_id`),
  KEY `fk_jobs_source` (`source_id`),
  KEY `fk_jobs_user` (`requested_by`),
  CONSTRAINT `fk_jobs_parent` FOREIGN KEY (`parent_job_id`) REFERENCES `pipeline_jobs` (`job_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jobs_source` FOREIGN KEY (`source_id`) REFERENCES `music_sources` (`source_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jobs_user` FOREIGN KEY (`requested_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `chk_jobs_retry` CHECK ((`retry_count` <= (`max_retries` + 1))),
  CONSTRAINT `chk_jobs_times` CHECK (((`completed_at` is null) or (`started_at` is null) or (`completed_at` >= `started_at`)))
) ENGINE=InnoDB;

CREATE TABLE `source_records` (
  `record_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `source_id` smallint unsigned NOT NULL,
  `entity_type` enum('SONG','ARTIST','ALBUM','FILM') NOT NULL,
  `external_id` varchar(100) NOT NULL,
  `isrc` char(12) DEFAULT NULL,
  `song_id` int unsigned DEFAULT NULL,
  `artist_id` int unsigned DEFAULT NULL,
  `album_id` int unsigned DEFAULT NULL,
  `film_id` int unsigned DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `rights_status` enum('PERMITTED','ATTRIBUTION_REQUIRED','METADATA_ONLY','RESTRICTED','UNKNOWN') NOT NULL,
  `payload` json NOT NULL,
  `payload_hash` char(64) NOT NULL,
  `status` enum('DISCOVERED','VALIDATING','PROCESSING','COMPLETED','SKIPPED','FAILED','IN_REVIEW') NOT NULL DEFAULT 'DISCOVERED',
  `match_method` enum('EXTERNAL_ID','ISRC','EXACT','FUZZY','NEW','MANUAL') DEFAULT NULL,
  `match_confidence` decimal(4,3) DEFAULT NULL,
  `quality_score` decimal(4,3) DEFAULT NULL,
  `processing_version` varchar(20) NOT NULL,
  `last_job_id` bigint unsigned DEFAULT NULL,
  `first_seen_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_verified_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `uq_sr_external` (`source_id`,`entity_type`,`external_id`),
  KEY `idx_sr_isrc` (`isrc`),
  KEY `idx_sr_song` (`song_id`),
  KEY `idx_sr_status` (`status`),
  KEY `fk_sr_artist` (`artist_id`),
  KEY `fk_sr_album` (`album_id`),
  KEY `fk_sr_film` (`film_id`),
  KEY `fk_sr_job` (`last_job_id`),
  CONSTRAINT `fk_sr_album` FOREIGN KEY (`album_id`) REFERENCES `albums` (`album_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sr_artist` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`artist_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sr_film` FOREIGN KEY (`film_id`) REFERENCES `films` (`film_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sr_job` FOREIGN KEY (`last_job_id`) REFERENCES `pipeline_jobs` (`job_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sr_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sr_source` FOREIGN KEY (`source_id`) REFERENCES `music_sources` (`source_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_sr_entity` CHECK ((((`entity_type` = 'SONG') and (`artist_id` is null) and (`album_id` is null) and (`film_id` is null)) or ((`entity_type` = 'ARTIST') and (`song_id` is null) and (`album_id` is null) and (`film_id` is null)) or ((`entity_type` = 'ALBUM') and (`song_id` is null) and (`artist_id` is null) and (`film_id` is null)) or ((`entity_type` = 'FILM') and (`song_id` is null) and (`artist_id` is null) and (`album_id` is null)))),
  CONSTRAINT `chk_sr_scores` CHECK ((((`match_confidence` is null) or (`match_confidence` between 0 and 1)) and ((`quality_score` is null) or (`quality_score` between 0 and 1))))
) ENGINE=InnoDB;

CREATE TABLE `pipeline_job_logs` (
  `log_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint unsigned NOT NULL,
  `level` enum('INFO','WARN','ERROR') NOT NULL,
  `stage` varchar(30) NOT NULL,
  `message` varchar(500) NOT NULL,
  `record_id` bigint unsigned DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`log_id`),
  KEY `idx_logs_job` (`job_id`,`log_id`),
  KEY `idx_logs_level` (`level`,`created_at`),
  KEY `fk_logs_record` (`record_id`),
  CONSTRAINT `fk_logs_job` FOREIGN KEY (`job_id`) REFERENCES `pipeline_jobs` (`job_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_logs_record` FOREIGN KEY (`record_id`) REFERENCES `source_records` (`record_id`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE `playback_events` (
  `event_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `play_id` bigint unsigned NOT NULL,
  `event_type` enum('PLAY_STARTED','PAUSE','RESUME','SEEK','SKIP','COMPLETED','REPLAY') NOT NULL,
  `position_sec` smallint unsigned NOT NULL,
  `seek_to_sec` smallint unsigned DEFAULT NULL,
  `occurred_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`event_id`),
  KEY `idx_pe_play` (`play_id`,`occurred_at`),
  CONSTRAINT `fk_pe_play` FOREIGN KEY (`play_id`) REFERENCES `listening_history` (`play_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_pe_seek` CHECK (((`event_type` = 'SEEK') = (`seek_to_sec` is not null)))
) ENGINE=InnoDB;

CREATE TABLE `playlists` (
  `playlist_id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `kind` enum('MANUAL','SMART','SAVED_MIX','WORLD') NOT NULL DEFAULT 'MANUAL',
  `smart_type` varchar(30) DEFAULT NULL,
  `source_batch_id` bigint unsigned DEFAULT NULL,
  `song_count` smallint unsigned NOT NULL DEFAULT '0',
  `total_duration_sec` int unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`playlist_id`),
  UNIQUE KEY `uq_playlists_user_name` (`user_id`,`name`),
  KEY `fk_pl_batch` (`source_batch_id`),
  CONSTRAINT `fk_pl_batch` FOREIGN KEY (`source_batch_id`) REFERENCES `recommendation_batches` (`batch_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_pl_name` CHECK ((char_length(trim(`name`)) >= 1)),
  CONSTRAINT `chk_pl_smart` CHECK (((`kind` = 'SMART') = (`smart_type` is not null)))
) ENGINE=InnoDB;

CREATE TABLE `playlist_songs` (
  `playlist_id` int unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `position` smallint unsigned NOT NULL DEFAULT '0',
  `added_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`playlist_id`,`song_id`),
  KEY `idx_ps_song` (`song_id`),
  CONSTRAINT `fk_ps_playlist` FOREIGN KEY (`playlist_id`) REFERENCES `playlists` (`playlist_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ps_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `ratings` (
  `user_id` int unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `rating` tinyint unsigned NOT NULL,
  `rated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`song_id`),
  KEY `idx_ratings_song` (`song_id`,`rating`),
  CONSTRAINT `fk_ratings_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ratings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ratings_value` CHECK ((`rating` between 1 and 5))
) ENGINE=InnoDB;

CREATE TABLE `reason_types` (
  `reason_code` varchar(30) NOT NULL,
  `template` varchar(160) NOT NULL,
  `score_family` varchar(30) NOT NULL,
  PRIMARY KEY (`reason_code`)
) ENGINE=InnoDB;

CREATE TABLE `recommendation_batch_moods` (
  `batch_id` bigint unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `weight` decimal(3,2) NOT NULL,
  PRIMARY KEY (`batch_id`,`mood_id`),
  KEY `idx_rbm_mood` (`mood_id`),
  CONSTRAINT `fk_rbm_batch` FOREIGN KEY (`batch_id`) REFERENCES `recommendation_batches` (`batch_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rbm_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_rbm_weight` CHECK (((`weight` > 0) and (`weight` <= 1)))
) ENGINE=InnoDB;

CREATE TABLE `recommendation_items` (
  `batch_id` bigint unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `rank_position` smallint unsigned NOT NULL,
  `final_score` decimal(6,4) NOT NULL,
  `mood_score` decimal(6,4) DEFAULT NULL,
  `audio_score` decimal(6,4) NOT NULL,
  `preference_score` decimal(6,4) NOT NULL,
  `recency_score` decimal(6,4) DEFAULT NULL,
  `trend_score` decimal(6,4) NOT NULL,
  `context_score` decimal(6,4) DEFAULT NULL,
  `regional_score` decimal(6,4) DEFAULT NULL,
  `exploration_score` decimal(6,4) NOT NULL,
  `repetition_penalty` decimal(6,4) NOT NULL,
  PRIMARY KEY (`batch_id`,`song_id`),
  UNIQUE KEY `uq_ri_rank` (`batch_id`,`rank_position`),
  KEY `idx_ri_song` (`song_id`),
  CONSTRAINT `fk_ri_batch` FOREIGN KEY (`batch_id`) REFERENCES `recommendation_batches` (`batch_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ri_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ri_score` CHECK ((`final_score` between 0 and 1))
) ENGINE=InnoDB;

CREATE TABLE `recommendation_reasons` (
  `batch_id` bigint unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `reason_code` varchar(30) NOT NULL,
  `strength` decimal(5,3) NOT NULL,
  `params` json NOT NULL,
  PRIMARY KEY (`batch_id`,`song_id`,`reason_code`),
  KEY `idx_rr_code` (`reason_code`),
  CONSTRAINT `fk_rr_item` FOREIGN KEY (`batch_id`, `song_id`) REFERENCES `recommendation_items` (`batch_id`, `song_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rr_type` FOREIGN KEY (`reason_code`) REFERENCES `reason_types` (`reason_code`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `review_queue` (
  `review_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_type` enum('POSSIBLE_DUPLICATE','SUSPICIOUS_METADATA','FAILED_INGESTION','SOURCE_CONFLICT') NOT NULL,
  `record_id` bigint unsigned DEFAULT NULL,
  `candidate_song_id` int unsigned DEFAULT NULL,
  `job_id` bigint unsigned DEFAULT NULL,
  `score` decimal(4,3) DEFAULT NULL,
  `details` json NOT NULL,
  `status` enum('PENDING','APPROVED','REJECTED','MERGED','IGNORED','REPROCESS') NOT NULL DEFAULT 'PENDING',
  `pending_key` varchar(80) GENERATED ALWAYS AS (if((`status` = 'PENDING'),concat(`review_type`,':',coalesce(`record_id`,0)),NULL)) VIRTUAL,
  `decided_by` int unsigned DEFAULT NULL,
  `decided_at` datetime DEFAULT NULL,
  `decision_note` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`review_id`),
  UNIQUE KEY `uq_review_one_pending` (`pending_key`),
  KEY `idx_review_status` (`status`,`created_at`),
  KEY `fk_rq_record` (`record_id`),
  KEY `fk_rq_song` (`candidate_song_id`),
  KEY `fk_rq_job` (`job_id`),
  KEY `fk_rq_user` (`decided_by`),
  CONSTRAINT `fk_rq_job` FOREIGN KEY (`job_id`) REFERENCES `pipeline_jobs` (`job_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rq_record` FOREIGN KEY (`record_id`) REFERENCES `source_records` (`record_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rq_song` FOREIGN KEY (`candidate_song_id`) REFERENCES `songs` (`song_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rq_user` FOREIGN KEY (`decided_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `chk_rq_decided` CHECK (((`status` = 'PENDING') = (`decided_at` is null)))
) ENGINE=InnoDB;

CREATE TABLE `role_permissions` (
  `role_id` tinyint unsigned NOT NULL,
  `permission_code` varchar(40) NOT NULL,
  PRIMARY KEY (`role_id`,`permission_code`),
  KEY `fk_rp_perm` (`permission_code`),
  CONSTRAINT `fk_rp_perm` FOREIGN KEY (`permission_code`) REFERENCES `permissions` (`permission_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `schema_migrations` (
  `version` char(4) NOT NULL,
  `name` varchar(120) NOT NULL,
  `checksum` char(64) DEFAULT NULL,
  `applied_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_ms` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`),
  CONSTRAINT `chk_mig_version` CHECK (regexp_like(`version`,'^[0-9]{4}$'))
) ENGINE=InnoDB;

CREATE TABLE `search_history` (
  `search_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `query_text` varchar(120) NOT NULL,
  `normalized_query` varchar(120) NOT NULL,
  `result_count` smallint unsigned NOT NULL,
  `searched_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`search_id`),
  KEY `idx_sh_user_time` (`user_id`,`searched_at`),
  KEY `idx_sh_query` (`normalized_query`),
  CONSTRAINT `fk_sh_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `song_artists` (
  `song_id` int unsigned NOT NULL,
  `artist_id` int unsigned NOT NULL,
  `role` enum('FEATURED','COMPOSER','LYRICIST','PRODUCER') NOT NULL,
  `credit_order` tinyint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`song_id`,`artist_id`,`role`),
  KEY `idx_sa_artist` (`artist_id`),
  CONSTRAINT `fk_sa_artist` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`artist_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sa_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `song_dismissals` (
  `user_id` int unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `batch_id` bigint unsigned DEFAULT NULL,
  `dismissed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`song_id`),
  KEY `idx_dismiss_song` (`song_id`),
  KEY `idx_dismiss_batch` (`batch_id`),
  CONSTRAINT `fk_dismiss_batch` FOREIGN KEY (`batch_id`) REFERENCES `recommendation_batches` (`batch_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dismiss_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dismiss_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `song_genres` (
  `song_id` int unsigned NOT NULL,
  `genre_id` smallint unsigned NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `primary_song_key` int unsigned GENERATED ALWAYS AS (if((`is_primary` = 1),`song_id`,NULL)) VIRTUAL,
  PRIMARY KEY (`song_id`,`genre_id`),
  UNIQUE KEY `uq_sg_one_primary` (`primary_song_key`),
  KEY `idx_sg_genre` (`genre_id`,`is_primary`),
  CONSTRAINT `fk_sg_genre` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_sg_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `song_media` (
  `media_id` int unsigned NOT NULL AUTO_INCREMENT,
  `song_id` int unsigned NOT NULL,
  `source_id` smallint unsigned NOT NULL,
  `media_type` enum('PREVIEW','FULL','GENERATED_SKETCH','USER_LOCAL') NOT NULL,
  `uri` varchar(500) DEFAULT NULL,
  `rights_status` enum('PERMITTED','ATTRIBUTION_REQUIRED','RESTRICTED') NOT NULL,
  `availability` enum('AVAILABLE','UNAVAILABLE','UNCHECKED') NOT NULL DEFAULT 'UNCHECKED',
  `last_checked_at` datetime DEFAULT NULL,
  `attribution` varchar(200) DEFAULT NULL,
  `priority` tinyint unsigned NOT NULL DEFAULT '50',
  PRIMARY KEY (`media_id`),
  UNIQUE KEY `uq_media` (`song_id`,`source_id`,`media_type`),
  KEY `fk_media_source` (`source_id`),
  KEY `idx_media_song_avail` (`song_id`,`availability`),
  CONSTRAINT `fk_media_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_media_source` FOREIGN KEY (`source_id`) REFERENCES `music_sources` (`source_id`) ON DELETE RESTRICT,
  CONSTRAINT `chk_media_uri` CHECK (((`media_type` = 'GENERATED_SKETCH') or (`uri` is not null)))
) ENGINE=InnoDB;

CREATE TABLE `song_mood_curations` (
  `song_id` int unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `action` enum('ADD','REMOVE') NOT NULL,
  `confidence` decimal(4,3) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `curated_by` int unsigned DEFAULT NULL,
  `curated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`song_id`,`mood_id`),
  KEY `idx_smc_mood` (`mood_id`),
  KEY `fk_smc_curator` (`curated_by`),
  CONSTRAINT `fk_smc_curator` FOREIGN KEY (`curated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_smc_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_smc_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_smc_conf` CHECK ((((`action` = 'ADD') and (`confidence` > 0) and (`confidence` <= 1)) or ((`action` = 'REMOVE') and (`confidence` is null))))
) ENGINE=InnoDB;

CREATE TABLE `song_mood_ratings` (
  `user_id` int unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `match_percentage` decimal(5,2) NOT NULL,
  `review_text` varchar(280) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`song_id`,`mood_id`),
  KEY `idx_smr_song_mood` (`song_id`,`mood_id`,`match_percentage`),
  KEY `idx_smr_mood_song` (`mood_id`,`song_id`,`match_percentage`),
  CONSTRAINT `fk_smr_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_smr_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_smr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_smr_pct` CHECK (((`match_percentage` >= 0) and (`match_percentage` <= 100))),
  CONSTRAINT `chk_smr_review` CHECK (((`review_text` is null) or (char_length(trim(`review_text`)) > 0)))
) ENGINE=InnoDB;

CREATE TABLE `song_moods` (
  `song_id` int unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `model_id` smallint unsigned NOT NULL,
  `confidence` decimal(4,3) NOT NULL,
  `feature_id` int unsigned NOT NULL,
  `analyzed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`song_id`,`mood_id`,`model_id`),
  KEY `idx_sm_model_mood` (`model_id`,`mood_id`,`confidence`),
  KEY `fk_sm_mood` (`mood_id`),
  KEY `fk_sm_feature` (`feature_id`),
  CONSTRAINT `fk_sm_feature` FOREIGN KEY (`feature_id`) REFERENCES `audio_features` (`feature_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sm_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_sm_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sm_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_sm_conf` CHECK (((`confidence` > 0) and (`confidence` <= 1)))
) ENGINE=InnoDB;

CREATE TABLE `trend_snapshots` (
  `snapshot_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint unsigned NOT NULL,
  `window_code` enum('24H','7D','30D') NOT NULL,
  `entity_type` enum('SONG','ARTIST','GENRE','MOOD','LANGUAGE') NOT NULL,
  `entity_id` int unsigned NOT NULL,
  `region_code` varchar(6) DEFAULT NULL,
  `region_key` varchar(6) GENERATED ALWAYS AS (coalesce(`region_code`,'ALL')) VIRTUAL,
  `curr_plays` int unsigned NOT NULL,
  `prev_plays` int unsigned NOT NULL,
  `curr_listeners` int unsigned NOT NULL,
  `velocity_pct` decimal(8,2) DEFAULT NULL,
  `momentum_rank` smallint unsigned NOT NULL,
  `computed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`snapshot_id`),
  UNIQUE KEY `uq_trend` (`job_id`,`window_code`,`entity_type`,`region_key`,`entity_id`),
  KEY `fk_trend_region` (`region_code`),
  KEY `idx_trend_lookup` (`window_code`,`entity_type`,`region_key`,`job_id`,`momentum_rank`),
  CONSTRAINT `fk_trend_job` FOREIGN KEY (`job_id`) REFERENCES `pipeline_jobs` (`job_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_trend_region` FOREIGN KEY (`region_code`) REFERENCES `regions` (`region_code`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `user_artist_preferences` (
  `user_id` int unsigned NOT NULL,
  `artist_id` int unsigned NOT NULL,
  `onboarding_weight` decimal(4,3) NOT NULL DEFAULT '0.000',
  `plays` int unsigned NOT NULL DEFAULT '0',
  `completes` int unsigned NOT NULL DEFAULT '0',
  `skips` int unsigned NOT NULL DEFAULT '0',
  `replays` int unsigned NOT NULL DEFAULT '0',
  `listen_sec` int unsigned NOT NULL DEFAULT '0',
  `short_term_score` decimal(9,4) NOT NULL DEFAULT '0.0000',
  `long_term_score` decimal(9,4) NOT NULL DEFAULT '0.0000',
  `blended_score` decimal(5,4) NOT NULL DEFAULT '0.0000',
  `last_played_at` datetime DEFAULT NULL,
  `model_id` smallint unsigned DEFAULT NULL,
  `computed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`artist_id`),
  KEY `idx_uap_rank` (`user_id`,`blended_score`),
  KEY `fk_uap_artist` (`artist_id`),
  KEY `fk_uap_model` (`model_id`),
  CONSTRAINT `fk_uap_artist` FOREIGN KEY (`artist_id`) REFERENCES `artists` (`artist_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uap_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uap_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_uap` CHECK (((`onboarding_weight` between 0 and 1) and (`blended_score` between 0 and 1)))
) ENGINE=InnoDB;

CREATE TABLE `user_context_preferences` (
  `user_id` int unsigned NOT NULL,
  `context_id` tinyint unsigned NOT NULL,
  `onboarding_weight` decimal(4,3) NOT NULL DEFAULT '0.000',
  `sessions` int unsigned NOT NULL DEFAULT '0',
  `listen_sec` int unsigned NOT NULL DEFAULT '0',
  `blended_score` decimal(5,4) NOT NULL DEFAULT '0.0000',
  `computed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`context_id`),
  KEY `fk_ucp_ctx` (`context_id`),
  CONSTRAINT `fk_ucp_ctx` FOREIGN KEY (`context_id`) REFERENCES `contexts` (`context_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ucp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ucp` CHECK (((`onboarding_weight` between 0 and 1) and (`blended_score` between 0 and 1)))
) ENGINE=InnoDB;

CREATE TABLE `user_genre_preferences` (
  `user_id` int unsigned NOT NULL,
  `genre_id` smallint unsigned NOT NULL,
  `onboarding_weight` decimal(4,3) NOT NULL DEFAULT '0.000',
  `plays` int unsigned NOT NULL DEFAULT '0',
  `completes` int unsigned NOT NULL DEFAULT '0',
  `skips` int unsigned NOT NULL DEFAULT '0',
  `replays` int unsigned NOT NULL DEFAULT '0',
  `listen_sec` int unsigned NOT NULL DEFAULT '0',
  `short_term_score` decimal(9,4) NOT NULL DEFAULT '0.0000',
  `long_term_score` decimal(9,4) NOT NULL DEFAULT '0.0000',
  `blended_score` decimal(5,4) NOT NULL DEFAULT '0.0000',
  `last_played_at` datetime DEFAULT NULL,
  `model_id` smallint unsigned DEFAULT NULL,
  `computed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`genre_id`),
  KEY `idx_ugp_rank` (`user_id`,`blended_score`),
  KEY `fk_ugp_genre` (`genre_id`),
  KEY `fk_ugp_model` (`model_id`),
  CONSTRAINT `fk_ugp_genre` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ugp_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ugp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ugp` CHECK (((`onboarding_weight` between 0 and 1) and (`blended_score` between 0 and 1)))
) ENGINE=InnoDB;

CREATE TABLE `user_languages` (
  `user_id` int unsigned NOT NULL,
  `language_id` smallint unsigned NOT NULL,
  `priority` tinyint unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`language_id`),
  UNIQUE KEY `uq_ul_priority` (`user_id`,`priority`),
  KEY `fk_ul_lang` (`language_id`),
  CONSTRAINT `fk_ul_lang` FOREIGN KEY (`language_id`) REFERENCES `languages` (`language_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ul_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ul_priority` CHECK ((`priority` between 1 and 10))
) ENGINE=InnoDB;

CREATE TABLE `user_likes` (
  `user_id` int unsigned NOT NULL,
  `song_id` int unsigned NOT NULL,
  `liked_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`song_id`),
  KEY `idx_likes_song` (`song_id`),
  KEY `idx_likes_user_time` (`user_id`,`liked_at`),
  CONSTRAINT `fk_likes_song` FOREIGN KEY (`song_id`) REFERENCES `songs` (`song_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_likes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `user_mood_preferences` (
  `user_id` int unsigned NOT NULL,
  `mood_id` smallint unsigned NOT NULL,
  `onboarding_weight` decimal(4,3) NOT NULL DEFAULT '0.000',
  `plays` int unsigned NOT NULL DEFAULT '0',
  `short_term_score` decimal(9,4) NOT NULL DEFAULT '0.0000',
  `long_term_score` decimal(9,4) NOT NULL DEFAULT '0.0000',
  `blended_score` decimal(5,4) NOT NULL DEFAULT '0.0000',
  `last_played_at` datetime DEFAULT NULL,
  `model_id` smallint unsigned DEFAULT NULL,
  `computed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`mood_id`),
  KEY `idx_ump_rank` (`user_id`,`blended_score`),
  KEY `fk_ump_mood` (`mood_id`),
  KEY `fk_ump_model` (`model_id`),
  CONSTRAINT `fk_ump_model` FOREIGN KEY (`model_id`) REFERENCES `intelligence_models` (`model_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ump_mood` FOREIGN KEY (`mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ump_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ump` CHECK (((`onboarding_weight` between 0 and 1) and (`blended_score` between 0 and 1)))
) ENGINE=InnoDB;

CREATE TABLE `user_profiles` (
  `user_id` int unsigned NOT NULL,
  `display_name` varchar(60) NOT NULL,
  `region_code` varchar(6) DEFAULT NULL,
  `content_filter` enum('OFF','NO_EXPLICIT','FAMILY') NOT NULL DEFAULT 'OFF',
  `listening_habit` enum('BACKGROUND','ACTIVE','MIXED') DEFAULT NULL,
  `onboarding_completed_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  KEY `fk_up_region` (`region_code`),
  CONSTRAINT `fk_up_region` FOREIGN KEY (`region_code`) REFERENCES `regions` (`region_code`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_up_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `weekly_worlds` (
  `world_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `week_start` date NOT NULL,
  `version` smallint unsigned NOT NULL,
  `archetype_code` varchar(20) NOT NULL,
  `title` varchar(80) NOT NULL,
  `description` varchar(300) NOT NULL,
  `primary_mood_id` smallint unsigned NOT NULL,
  `language_id` smallint unsigned DEFAULT NULL,
  `region_code` varchar(6) DEFAULT NULL,
  `theme` json NOT NULL,
  `signals` json NOT NULL,
  `batch_id` bigint unsigned NOT NULL,
  `job_id` bigint unsigned DEFAULT NULL,
  `status` enum('ACTIVE','SUPERSEDED','ROLLED_BACK') NOT NULL DEFAULT 'ACTIVE',
  `active_key` varchar(30) GENERATED ALWAYS AS (if((`status` = 'ACTIVE'),concat(`user_id`,':',`week_start`),NULL)) VIRTUAL,
  `generated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`world_id`),
  UNIQUE KEY `uq_world_version` (`user_id`,`week_start`,`version`),
  UNIQUE KEY `uq_world_batch` (`batch_id`),
  UNIQUE KEY `uq_world_one_active` (`active_key`),
  KEY `fk_ww_arch` (`archetype_code`),
  KEY `fk_ww_mood` (`primary_mood_id`),
  KEY `fk_ww_lang` (`language_id`),
  KEY `fk_ww_region` (`region_code`),
  KEY `fk_ww_job` (`job_id`),
  CONSTRAINT `fk_ww_arch` FOREIGN KEY (`archetype_code`) REFERENCES `world_archetypes` (`archetype_code`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_ww_batch` FOREIGN KEY (`batch_id`) REFERENCES `recommendation_batches` (`batch_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ww_job` FOREIGN KEY (`job_id`) REFERENCES `pipeline_jobs` (`job_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ww_lang` FOREIGN KEY (`language_id`) REFERENCES `languages` (`language_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ww_mood` FOREIGN KEY (`primary_mood_id`) REFERENCES `moods` (`mood_id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_ww_region` FOREIGN KEY (`region_code`) REFERENCES `regions` (`region_code`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ww_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ww_expiry` CHECK ((`expires_at` > `generated_at`)),
  CONSTRAINT `chk_ww_week` CHECK ((dayofweek(`week_start`) = 2))
) ENGINE=InnoDB;

CREATE TABLE `world_feedback` (
  `user_id` int unsigned NOT NULL,
  `world_id` bigint unsigned NOT NULL,
  `feedback` enum('LOVE','NOT_FOR_ME') NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`world_id`),
  KEY `idx_wf_world` (`world_id`),
  CONSTRAINT `fk_wf_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wf_world` FOREIGN KEY (`world_id`) REFERENCES `weekly_worlds` (`world_id`) ON DELETE CASCADE
) ENGINE=InnoDB;
